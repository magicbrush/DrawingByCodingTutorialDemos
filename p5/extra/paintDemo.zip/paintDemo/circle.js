
function circle(
	x,y,radius, 
	amp, freq, phase )
{
	this.x = x;
	this.y = y;
	this.radius = radius;
	this.amplitude = amp;
	this.frequence= freq;
	this.phase = phase;

	this.draw = function()
	{
		var secs = millis()/1000.0;
		var rBias = 
			this.amplitude * 
			sin(this.frequence * secs + this.phase);
		var r = this.radius + rBias;
		
		push();
		noStroke();
		strokeWeight(0.2);
		stroke(0,0,0,50);
		fill(0,10);
		translate(this.x,this.y);
		scale(r,r);
		ellipse(0,0,1,1);
		pop();
	}

	this.toJson = function()
	{
		var jsonObj = {};
		jsonObj.x = this.x;
		jsonObj.y = this.y;
		jsonObj.radius = this.radius;
		jsonObj.amplitude = this.amplitude;
		jsonObj.frequence = this.frequence;
		jsonObj.phase = this.phase;
		return jsonObj;
	}

	this.fromJson = function(jsonObj)
	{
		this.x = jsonObj.x;
		this.y = jsonObj.y;
		this.radius = jsonObj.radius;
		this.amplitude = jsonObj.amplitude;
		this.frequence = jsonObj.frequence;
		this.phase = jsonObj.phase;
	}	

}




