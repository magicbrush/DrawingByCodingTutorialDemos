var circles = new Array(); // 笔迹
var brushStroke; // 选择默认笔刷
var brushId = 0;

function setup() {
	createCanvas(700,280);
	brushStroke = brushes[brushId];
}

function draw() {
	background(255,6);
	
	for(var i=0;i<circles.length;i++)
	{
		var c = circles[i];
		c.draw();
	}

	textSize(12);
	//text(brushStroke,10,10);
	//print("circle count:" + circles.length);
	text("up/down: select brush",10,height-10);
	text("c: clear canvas",10,height-30);
	//text("key:" + pressKey,10,30);

	textSize(12);
	text("brush:" + brushId, 10,10);

}

// *************** 用鼠标画画 ***************//
function mousePressed()
{
	print("mousePressed:" + millis());
	brushStroke();
}

function mouseDragged()
{
	print("mouseDragged:" + millis());	
	brushStroke();
}


function mouseReleased()
{
	print("mouseReleased:" + millis());
}

function mouseClicked()
{
	print("mouseClicked:" + millis());
}

function doubleClicked()
{
	print("doubleClicked:" + millis());
}

function touchStarted()
{
	print("TouchStarted:" + millis());
}


function touchEnded()
{
	print("touchEnded:" + millis());
}

function touchMoved()
{
	print("touchMoved:" + millis());
}

// *************** 用键盘进行设置 ***************//
// 用0~9按键选择笔刷
// 用按键c清除画布
// 用按键s,l保存和读取(待实现)
var pressKey;
var pressKeyCode;

function keyPressed()
{
	pressKey = key;
	pressKeyCode = keyCode;
}


function keyReleased()
{
	
	if(pressKey=='S')
	{
		//print("Save(S)");
		//saveAsJson(circles);
	}
	else if(pressKey=="L")
	{
		//print("Load(L)");
		//loadFromJson("./save/circles.json");
	}
	else if(pressKey=="C")
	{
		circles = new Array();
	}

	if(pressKeyCode == UP_ARROW)
	{
		brushId ++;
		PickBrushById();
	}
	else if(pressKeyCode == DOWN_ARROW)
	{
		brushId --;
		PickBrushById();
	}

	print("key:" + key + " keyCode:" + keyCode);
}

function PickBrushById()
{
	if(brushId>=brushes.length)
	{
		brushId=0;
	}
	else if(brushId<0)
	{
		brushId = brushes.length-1
	}
	brushStroke = brushes[brushId];
}



